package src;

public enum difficultyLevel {
    Easy, Medium, Madness;



}
